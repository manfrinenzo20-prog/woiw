import { Crown, Star, Leaf, Zap, ShieldCheck, Award, Users, ChevronDown } from "lucide-react";

const creators = [
  "Enzo", "Alice", "Pedro", "Josué", "Maria", "João Pedro", "Lorena",
];

const features = [
  { icon: <Leaf className="w-6 h-6" />, title: "Sem Corantes Artificiais", desc: "Feito com ingredientes naturais, sem aditivos artificiais." },
  { icon: <Award className="w-6 h-6" />, title: "Cacau Selecionado", desc: "Utilizamos apenas os melhores grãos de cacau em nosso recheio." },
  { icon: <Star className="w-6 h-6" />, title: "Mais Sabor", desc: "Receita exclusiva desenvolvida para proporcionar experiência única." },
  { icon: <Zap className="w-6 h-6" />, title: "Fonte de Energia", desc: "Combinação equilibrada que fornece energia para o seu dia." },
];

export default function App() {
  return (
    <div className="min-h-screen bg-[#FAF7F2] font-sans text-gray-900">
      {/* Header */}
      <header className="bg-[#4A1080] text-white py-4 px-6 flex items-center justify-between sticky top-0 z-50 shadow-lg">
        <div className="flex items-center gap-2">
          <Crown className="w-5 h-5 text-amber-400" />
          <span className="font-bold text-lg tracking-widest uppercase text-amber-400">Delícia</span>
        </div>
        <nav className="hidden md:flex gap-8 text-sm font-medium tracking-wide">
          <a href="#produto" className="hover:text-amber-400 transition-colors">Produto</a>
          <a href="#diferenciais" className="hover:text-amber-400 transition-colors">Diferenciais</a>
          <a href="#equipe" className="hover:text-amber-400 transition-colors">Equipe</a>
        </nav>
        <span className="text-amber-400 font-bold text-base">R$ 15,00</span>
      </header>

      {/* Hero */}
      <section className="relative bg-gradient-to-br from-[#4A1080] via-[#6B21A8] to-[#3B0764] overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute rounded-full bg-amber-400"
              style={{
                width: `${Math.random() * 120 + 20}px`,
                height: `${Math.random() * 120 + 20}px`,
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                opacity: Math.random() * 0.5 + 0.1,
              }}
            />
          ))}
        </div>

        <div className="relative max-w-6xl mx-auto px-6 py-20 md:py-28 grid md:grid-cols-2 gap-12 items-center">
          <div className="text-white space-y-6">
            <div className="inline-flex items-center gap-2 bg-amber-400/20 border border-amber-400/40 rounded-full px-4 py-1.5 text-amber-300 text-sm font-medium tracking-wide">
              <Crown className="w-4 h-4" /> Desde 1998
            </div>
            <h1 className="text-5xl md:text-6xl font-extrabold leading-tight">
              Biscoito
              <br />
              <span className="text-amber-400">Recheado</span>
              <br />
              de Chocolate
            </h1>
            <p className="text-purple-200 text-lg leading-relaxed max-w-md">
              Crocante por fora, cremoso por dentro. Uma experiência irresistível que combina o melhor do cacau selecionado com uma textura única e inconfundível.
            </p>
            <div className="flex flex-wrap gap-4 pt-2">
              <a
                href="#produto"
                className="bg-amber-400 hover:bg-amber-300 text-[#3B0764] font-bold px-8 py-3 rounded-full transition-all duration-200 shadow-lg hover:shadow-amber-400/40 hover:-translate-y-0.5"
              >
                Conhecer Produto
              </a>
              <a
                href="#diferenciais"
                className="border-2 border-white/30 hover:border-amber-400 text-white hover:text-amber-400 font-semibold px-8 py-3 rounded-full transition-all duration-200"
              >
                Diferenciais
              </a>
            </div>
          </div>

          <div className="flex justify-center">
            <div className="relative">
              <div className="absolute -inset-8 bg-amber-400/20 rounded-full blur-3xl" />
              <img
                src="/WhatsApp_Image_2026-06-03_at_7.08.26_PM.jpeg"
                alt="Delícia Biscoito Recheado de Chocolate"
                className="relative w-full max-w-sm md:max-w-md rounded-2xl shadow-2xl object-cover"
              />
            </div>
          </div>
        </div>

        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-white/40 animate-bounce">
          <ChevronDown className="w-6 h-6" />
        </div>
      </section>

      {/* Stats Bar */}
      <div className="bg-amber-400 py-5">
        <div className="max-w-6xl mx-auto px-6 grid grid-cols-3 gap-4 text-center">
          {[
            { value: "120g", label: "Peso Líquido" },
            { value: "R$ 15", label: "Preço" },
            { value: "+25 anos", label: "de Tradição" },
          ].map((item) => (
            <div key={item.label}>
              <div className="text-2xl md:text-3xl font-extrabold text-[#3B0764]">{item.value}</div>
              <div className="text-sm font-medium text-[#4A1080]/80 mt-0.5">{item.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Produto */}
      <section id="produto" className="py-20 px-6 max-w-6xl mx-auto">
        <div className="text-center mb-14 space-y-3">
          <span className="text-[#6B21A8] font-semibold tracking-widest uppercase text-sm">O Produto</span>
          <h2 className="text-4xl font-extrabold text-gray-900">Delícia Biscoito Recheado</h2>
          <p className="text-gray-500 max-w-xl mx-auto leading-relaxed">
            Uma bolacha doce de alta qualidade, produzida com ingredientes cuidadosamente selecionados para garantir o melhor sabor em cada mordida.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm space-y-4">
              <h3 className="font-bold text-lg text-[#4A1080] flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-amber-500" /> Informações do Produto
              </h3>
              <div className="divide-y divide-gray-100">
                {[
                  { label: "Categoria", value: "Biscoito Recheado" },
                  { label: "Sabor", value: "Chocolate" },
                  { label: "Peso Líquido", value: "120g" },
                  { label: "Preço", value: "R$ 15,00" },
                  { label: "Corantes Artificiais", value: "Não contém" },
                  { label: "Cacau", value: "Selecionado" },
                ].map((row) => (
                  <div key={row.label} className="flex justify-between items-center py-3">
                    <span className="text-sm text-gray-500 font-medium">{row.label}</span>
                    <span className="text-sm font-semibold text-gray-800">{row.value}</span>
                  </div>
                ))}
              </div>
            </div>

            <blockquote className="border-l-4 border-amber-400 pl-5 italic text-gray-600 text-base">
              "Crocante por fora, cremoso por dentro — a combinação perfeita para quem aprecia um biscoito de verdade."
            </blockquote>
          </div>

          <div className="relative flex justify-center">
            <div className="absolute inset-0 bg-gradient-to-br from-purple-100 to-amber-50 rounded-3xl -rotate-2" />
            <img
              src="/WhatsApp_Image_2026-06-03_at_7.08.26_PM.jpeg"
              alt="Delícia Biscoito Recheado de Chocolate"
              className="relative rounded-3xl shadow-xl w-full max-w-sm object-cover rotate-1 hover:rotate-0 transition-transform duration-300"
            />
          </div>
        </div>
      </section>

      {/* Diferenciais */}
      <section id="diferenciais" className="bg-[#4A1080] py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14 space-y-3">
            <span className="text-amber-400 font-semibold tracking-widest uppercase text-sm">Por que Delícia?</span>
            <h2 className="text-4xl font-extrabold text-white">Nossos Diferenciais</h2>
            <p className="text-purple-200 max-w-xl mx-auto leading-relaxed">
              Cada detalhe foi pensado para entregar a melhor experiência ao consumidor, do ingrediente à embalagem.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((f) => (
              <div
                key={f.title}
                className="bg-white/10 hover:bg-white/20 backdrop-blur border border-white/10 rounded-2xl p-6 space-y-3 transition-all duration-200 hover:-translate-y-1"
              >
                <div className="w-12 h-12 bg-amber-400/20 border border-amber-400/30 rounded-xl flex items-center justify-center text-amber-400">
                  {f.icon}
                </div>
                <h3 className="font-bold text-white text-base">{f.title}</h3>
                <p className="text-purple-200 text-sm leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Equipe */}
      <section id="equipe" className="py-20 px-6 max-w-6xl mx-auto">
        <div className="text-center mb-14 space-y-3">
          <span className="text-[#6B21A8] font-semibold tracking-widest uppercase text-sm">Quem Faz</span>
          <h2 className="text-4xl font-extrabold text-gray-900">Nossa Equipe</h2>
          <p className="text-gray-500 max-w-xl mx-auto leading-relaxed">
            Por trás de cada biscoito há uma equipe dedicada e apaixonada por confeitaria e qualidade.
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-4">
          {creators.map((name, i) => (
            <div
              key={name}
              className="flex items-center gap-3 bg-white border border-gray-100 shadow-sm rounded-full px-5 py-3 hover:border-[#6B21A8]/30 hover:shadow-md transition-all duration-200"
            >
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-xs shrink-0"
                style={{ background: i % 2 === 0 ? "#4A1080" : "#D97706" }}
              >
                {name.charAt(0)}
              </div>
              <span className="font-semibold text-gray-700 text-sm">{name}</span>
            </div>
          ))}
        </div>

        <div className="mt-14 bg-gradient-to-br from-[#4A1080] to-[#6B21A8] rounded-3xl p-8 md:p-12 flex flex-col md:flex-row items-center gap-8 text-white">
          <Users className="w-16 h-16 text-amber-400 shrink-0" />
          <div className="space-y-2 text-center md:text-left">
            <h3 className="text-2xl font-extrabold">Empresa de Bolachas Doces</h3>
            <p className="text-purple-200 leading-relaxed max-w-lg">
              Somos uma empresa especializada em bolachas e biscoitos artesanais, fundada com o propósito de levar prazer e qualidade à mesa das famílias brasileiras. Nossos produtos são desenvolvidos com rigor técnico, ingredientes premium e muita paixão pela confeitaria.
            </p>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-amber-400 py-16 px-6 text-center">
        <div className="max-w-2xl mx-auto space-y-5">
          <h2 className="text-3xl md:text-4xl font-extrabold text-[#3B0764]">Experimente a Delícia</h2>
          <p className="text-[#4A1080]/80 text-lg">
            Por apenas <strong>R$ 15,00</strong> leve para casa o biscoito recheado de chocolate mais gostoso do mercado.
          </p>
          <div className="inline-block bg-[#3B0764] text-amber-400 font-bold text-3xl px-10 py-4 rounded-2xl shadow-xl">
            R$ 15,00
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#1E0438] text-purple-300 py-8 px-6 text-center space-y-2">
        <div className="flex items-center justify-center gap-2 mb-3">
          <Crown className="w-4 h-4 text-amber-400" />
          <span className="font-bold text-amber-400 tracking-widest uppercase text-sm">Delícia</span>
        </div>
        <p className="text-sm">Biscoito Recheado de Chocolate &mdash; 120g &mdash; R$ 15,00</p>
        <p className="text-xs text-purple-500 mt-2">
          &copy; {new Date().getFullYear()} Empresa de Bolachas Doces. Todos os direitos reservados.
        </p>
      </footer>
    </div>
  );
}
